//
//  PhotoView.swift
//  estrellita azul
//
//  Created by Alumno on 13/04/23.
//

import SwiftUI

struct PhotoView: View {
    var body: some View {
        
        Text("Mi Vista")
            
    }
}

struct PhotoView_Previews: PreviewProvider {
    static var previews: some View {
        PhotoView()
    }
}
